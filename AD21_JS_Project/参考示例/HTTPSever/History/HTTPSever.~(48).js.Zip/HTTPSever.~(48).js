////////////////////////////////////////////////////////////////////
// -----------------------------------------------------------------
// ��־���
function Log(msg) {
    ShowMessage(msg);
}
////
var PCB_Board;

// --------------------
// �ռ��������
// --------------------
function CopyBoardOutline(AWidth, ALayer)
{
    var I, J;
    var outlineData = [];

    PCB_Board.BoardOutline.Invalidate;
    PCB_Board.BoardOutline.Rebuild;
    PCB_Board.BoardOutline.Validate;

    for(I = 0; I < PCB_Board.BoardOutline.PointCount; I++)
    {
        if(I == PCB_Board.BoardOutline.PointCount - 1)
            J = 0;
        else
            J = I + 1;

        var seg = PCB_Board.BoardOutline.Segments(I);

        if(seg.Kind == ePolySegmentLine)
        {
            outlineData.push({
                shape: "line",
                x1: seg.vx,
                y1: seg.vy,
                x2: PCB_Board.BoardOutline.Segments(J).vx,
                y2: PCB_Board.BoardOutline.Segments(J).vy,
                width: AWidth,
                layer: ALayer
            });
        }
        else
        {
            outlineData.push({
                shape: "arc",
                cx: seg.cx,
                cy: seg.cy,
                radius: seg.Radius,
                angle1: seg.Angle1,
                angle2: seg.Angle2,
                width: AWidth,
                layer: ALayer
            });
        }
    }

    // ͳһ��װ JSON ��
    return {
        type: "outline",
        data: outlineData
    };
}

// --------------------
// ������Ϣ�������ã�
// --------------------
function SendMessage(payload, endpoint)
{
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/" + endpoint, false);
        http.setRequestHeader("Content-Type", "application/json");

        var jsonStr = JSON.stringify(payload);
        http.send(jsonStr);

        if(http.status == 200 && http.responseText == "OK")
            ShowMessage("��Ϣ���ͳɹ�");
        else
            ShowMessage("����ʧ��: " + http.status + " " + http.responseText);
    }
    catch(e) {
        ShowMessage("�����쳣: " + e.message);
    }
}

// -----------------------------------------------------------------
// ������Ϣ
function ReceiveMessages() {
    Log("������...");
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", "http://127.0.0.1:8080/poll", false);
        http.send();
        if(http.status == 200) {
            var resp = JSON.parse(http.responseText); // ȷ�� json2.js �Ѽ���
            if(resp.length === 0)
                Log("û������Ϣ");
            else
                for(var i=0;i<resp.length;i++)
                    Log("�յ���Ϣ: " + resp[i]);
        } else {
            Log("����ʧ��: " + http.status);
        }
    } catch(e) {
        Log("�����쳣: " + e.message);
    }
}

// -----------------------------------------------------------------
function GetScriptEngineInfo(){
   var s;
   s = ""; // Build string with necessary info.
   s += ScriptEngine() + " Version ";
   s += ScriptEngineMajorVersion() + ".";
   s += ScriptEngineMinorVersion() + ".";
   s += ScriptEngineBuildVersion();

   showmessage(s);
}

/*======================================================================
   �����ť
=======================================================================*/
function bSendClick(Sender)
{
    var Width, Layer;

    if(PCBServer == null)
        return;

    PCB_Board = PCBServer.GetCurrentPCBBoard;
    if(PCB_Board == null)
        return;

    StringToCoordUnit(eWidth.Text, Width, PCB_Board.DisplayUnit);
    Layer = String2Layer(cbLayers.Items(cbLayers.ItemIndex));

    var payload = CopyBoardOutline(Width, Layer);
    SendMessage(payload, "outline");

    Close;
}

function bReceiveClick(Sender)
{
    ReceiveMessages();
}

function bCancelClick(Sender)
{
    GetScriptEngineInfo();
    Close;
}

/*======================================================================
   ����ڣ��ű�ִ��ʱ�Զ�����
=======================================================================*/
function Main()
{
    GetScriptEngineInfo();
    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/send", false);
        http.setRequestHeader("Content-Type", "application/json");

        var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg==";
        http.send(JSON.stringify({ data: fileData }));

        if(http.status == 200 && http.responseText == "OK")
            ShowMessage("���ͳɹ�");
        else
            ShowMessage("����ʧ��: " + http.status);
    }
    catch(e)
    {
        ShowMessage("�����쳣: " + e.message);
    }
}
