// ���� POST ����
function httpPost(url, data, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", url, false); // ͬ��
        http.setRequestHeader("Content-Type", "application/json");
        http.send(JSON.stringify({ data: data }));
        if (http.status == 200 && http.responseText == "OK") callback(true);
        else callback(false);
    } catch(e){ callback(false); }
}

// ���� GET ����
function httpGet(url, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", url, false); // ͬ��
        http.send();
        if (http.status == 200) callback(http.responseText);
        else callback(null);
    } catch(e){ callback(null); }
}

function AddMessageToPanel(messageText, messageClass, imageIndex)
{
    if(PCBServer == null)
        return;

    var WSM = GetWorkSpace();
    if(WSM == null)
        return;

    var MM = WSM.DM_MessagesManager;
    if(MM == null)
        return;

    // ��ʼ��������
    MM.BeginUpdate();

    // Ĭ��ͼ�� Tick = 3
    if(imageIndex == null)
        imageIndex = 3;

    MM.AddMessage(
        messageClass || "MessageClass",
        messageText,
        "DXP Message",       // Source
        "",                  // Document
        "",                  // CallbackProcess
        "",                  // CallbackParams
        imageIndex,
        false                // bFatal
    );

    MM.EndUpdate();

    // ��ʾ��Ϣ���
    WSM.DM_ShowMessageView();
}


/*======================================================================
   ����������ļ�����ť
=======================================================================*/
function AddMessageToPanel(messageText, messageClass, imageIndex)
{
    if(PCBServer == null)
        return;

    var WSM = GetWorkSpace();
    if(WSM == null)
        return;

    var MM = WSM.DM_MessagesManager;
    if(MM == null)
        return;

    // ��ʼ��������
    MM.BeginUpdate();

    // Ĭ��ͼ�� Tick = 3
    if(imageIndex == null)
        imageIndex = 3;

    MM.AddMessage(
        messageClass || "MessageClass",
        messageText,
        "DXP Message",       // Source
        "",                  // Document
        "",                  // CallbackProcess
        "",                  // CallbackParams
        imageIndex,
        false                // bFatal
    );

    MM.EndUpdate();

    // ��ʾ��Ϣ���
    WSM.DM_ShowMessageView();
}


/*======================================================================
   �����������Ϣ����ť
=======================================================================*/
function bReceiveClick(Sender)
{
    if(PCBServer == null)
        return;

    PCB_Board = PCBServer.GetCurrentPCBBoard;
    if(PCB_Board == null)
        return;

    Sender.Caption = "������...";

    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", "http://127.0.0.1:8080/poll", false); // ͬ��
        http.send();
        ShowMessage("����");
        if(http.status == 200)
        {
            var resp = http.responseText;
            if(resp)
            {
                try
                {
                    var msgs = JSON.parse(resp);
                    if(msgs.length == 0)
                    {
                        ShowMessage("û������Ϣ");
                        Sender.Caption = "����Ϣ";
                    }
                    else
                    {
                        for(var i=0; i<msgs.length; i++)
                            ShowMessage("�յ� Godot ��Ϣ: " + msgs[i]);
                        Sender.Caption = "�������";
                    }
                }
                catch(e)
                {
                    ShowMessage("������Ϣʧ��");
                    Sender.Caption = "����ʧ��";
                }
            }
            else
            {
                ShowMessage("û���յ���Ϣ");
                Sender.Caption = "����Ϣ";
            }
        }
        else
        {
            ShowMessage("����ʧ��");
            Sender.Caption = "����ʧ��";
        }
    }
    catch(e)
    {
        ShowMessage("����ʧ��");
        Sender.Caption = "����ʧ��";
    }
}
