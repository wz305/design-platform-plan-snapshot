var http = new ActiveXObject("MSXML2.XMLHTTP");
http.open("GET", "http://127.0.0.1:8080/", false);
http.send();
WScript.Echo("Response: " + http.responseText);

