function GetScriptEngineInfo(){
   var s;
   s = ""; // Build string with necessary info.
   s += ScriptEngine() + " Version ";
   s += ScriptEngineMajorVersion() + ".";
   s += ScriptEngineMinorVersion() + ".";
   s += ScriptEngineBuildVersion();

   showmessage(s);
}

/*======================================================================
   ����������ļ�����ť
=======================================================================*/
function bSendClick(Sender)
{
    GetScriptEngineInfo();
    if(PCBServer == null)
        return;

    PCB_Board = PCBServer.GetCurrentPCBBoard;
    if(PCB_Board == null)
        return;

    if (Sender != null) Sender.Caption = "������...";

    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/send", false); // ͬ��
        http.setRequestHeader("Content-Type", "application/json");

        // ʾ�� Base64 �ļ�
        var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg==";
        http.send(JSON.stringify({ data: fileData }));

        if(http.status == 200 && http.responseText == "OK") {
            if (Sender != null) Sender.Caption = "���ͳɹ�";
            ShowMessage("���ͳɹ���");
        } else {
            if (Sender != null) Sender.Caption = "����ʧ��";
            ShowMessage("����ʧ�ܣ�״̬��" + http.status);
        }
    }
    catch(e)
    {
        if (Sender != null) Sender.Caption = "����ʧ��";
        ShowMessage("�쳣��" + e.message);
    }
}

function bCancelClick(Sender)
{
    GetScriptEngineInfo();
    Close;
}

/*======================================================================
   ����ڣ��ű�ִ��ʱ�Զ�����
=======================================================================*/
function Main()
{
    GetScriptEngineInfo();
    bSendClick(null);   // ֱ��ģ��㡰�����ļ���
}
