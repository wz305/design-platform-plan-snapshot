// ���� POST ����
function httpPost(url, data, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", url, false); // ͬ��
        http.setRequestHeader("Content-Type", "application/json");
        http.send(JSON.stringify({ data: data }));
        if (http.status == 200 && http.responseText == "OK") callback(true);
        else callback(false);
    } catch(e){ callback(false); }
}

// ���� GET ����
function httpGet(url, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", url, false); // ͬ��
        http.send();
        if (http.status == 200) callback(http.responseText);
        else callback(null);
    } catch(e){ callback(null); }
}

function AddMessageToPanel(messageText, messageClass, imageIndex)
{
    if(PCBServer == null)
        return;

    var WSM = GetWorkSpace();
    if(WSM == null)
        return;

    var MM = WSM.DM_MessagesManager;
    if(MM == null)
        return;

    // ��ʼ��������
    MM.BeginUpdate();

    // Ĭ��ͼ�� Tick = 3
    if(imageIndex == null)
        imageIndex = 3;

    MM.AddMessage(
        messageClass || "MessageClass",
        messageText,
        "DXP Message",       // Source
        "",                  // Document
        "",                  // CallbackProcess
        "",                  // CallbackParams
        imageIndex,
        false                // bFatal
    );

    MM.EndUpdate();

    // ��ʾ��Ϣ���
    WSM.DM_ShowMessageView();
}


/*======================================================================
   ����������ļ�����ť
=======================================================================*/
function bSendClick(Sender)
{
    Sender.Caption = "������...";
    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/send", false);
        http.setRequestHeader("Content-Type", "application/json");

        var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg==";
        http.send(JSON.stringify({ data: fileData }));

        if(http.status == 200 && http.responseText == "OK")
            AddMessageToPanel("���ͳɹ�", "SendFile", 3);
        else
            AddMessageToPanel("����ʧ��", "SendFile", 4);

        Sender.Caption = "�������";
    }
    catch(e)
    {
        AddMessageToPanel("����ʧ��", "SendFile", 4);
        Sender.Caption = "����ʧ��";
    }
}


/*======================================================================
   �����������Ϣ����ť
=======================================================================*/
function bSendClick(Sender)
{
    Sender.Caption = "������...";
    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/send", false);
        http.setRequestHeader("Content-Type", "application/json");

        var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg==";
        http.send(JSON.stringify({ data: fileData }));

        if(http.status == 200 && http.responseText == "OK")
            AddMessageToPanel("���ͳɹ�", "SendFile", 3);
        else
            AddMessageToPanel("����ʧ��", "SendFile", 4);

        Sender.Caption = "�������";
    }
    catch(e)
    {
        AddMessageToPanel("����ʧ��", "SendFile", 4);
        Sender.Caption = "����ʧ��";
    }
}

