try {
    var Http = new ActiveXObject("MSXML2.XMLHTTP");  // ���� XMLHTTP ����ͬ�� HTTP �ͻ��ˣ�

    Http.open("GET", "http://127.0.0.1:8080/", false);  // false = ͬ������ģʽ
    Http.send();

    if (Http.status == 200) {
        showmessage("Godot response: " + Http.responseText);
    } else {
        showmessage("HTTP Error: " + Http.status);
    }
} catch (e) {
    showmessage("HTTP request failed: " + e.message);
}

