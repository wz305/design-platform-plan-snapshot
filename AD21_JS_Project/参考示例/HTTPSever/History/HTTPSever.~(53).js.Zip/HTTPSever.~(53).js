//ȫ�ֱ���

var PCB_Board;
// ȫ�� TCP �ͻ������ӱ��
var tcpClient = null;

// -----------------------------
// ���� Godot
// -----------------------------
function connectToGodot(host, port) {
    try {
        if (!tcpClient) {
            tcpClient = new ActiveXObject("MSWinsock.Winsock"); // ������ Winsock COM
            tcpClient.RemoteHost = host;
            tcpClient.RemotePort = port;
            tcpClient.Connect();
            WScript.Sleep(100); // �ȴ����ӽ���
        }
        return tcpClient;
    } catch (e) {
        ShowMessage("����ʧ��: " + e.message);
        tcpClient = null;
        return null;
    }
}

// -----------------------------
// �������ݵ� Godot
// -----------------------------
function sendToGodot(payload) {
    if (!payload) return;

    if (!tcpClient) connectToGodot("127.0.0.1", 6000);
    if (!tcpClient) return;

    try {
        var msg = JSON.stringify(payload) + "\n"; // ������Ϊ��Ϣ�ָ�
        tcpClient.SendData(msg);

        // �ȴ� Godot ȷ��
        WScript.Sleep(50);
        var resp = tcpClient.GetData();
        if (resp && resp.indexOf("OK") >= 0) {
            ShowMessage("���ݷ��ͳɹ���");
        } else {
            ShowMessage("δ�յ�ȷ�ϣ�");
        }
    } catch (e) {
        ShowMessage("�����쳣: " + e.message);
        tcpClient = null; // �����Ͽ�����
    }
}

// -----------------------------
// ��ȡ�������
// -----------------------------
function getBoardOutlineData() {
    if (!PCB_Board) PCB_Board = PCBServer.GetCurrentPCBBoard;
    if (!PCB_Board) {
        ShowMessage("û�� PCB �壡");
        return null;
    }

    var outlineData = [];
    PCB_Board.BoardOutline.Invalidate;
    PCB_Board.BoardOutline.Rebuild;
    PCB_Board.BoardOutline.Validate;

    for (var i = 0; i < PCB_Board.BoardOutline.PointCount; i++) {
        var j = (i == PCB_Board.BoardOutline.PointCount - 1) ? 0 : i + 1;
        var seg = PCB_Board.BoardOutline.Segments(i);

        if (seg.Kind == ePolySegmentLine) {
            outlineData.push({
                kind: "line",
                x1: seg.vx,
                y1: seg.vy,
                x2: PCB_Board.BoardOutline.Segments(j).vx,
                y2: PCB_Board.BoardOutline.Segments(j).vy
            });
        } else {
            outlineData.push({
                kind: "arc",
                cx: seg.cx,
                cy: seg.cy,
                radius: seg.Radius,
                startAngle: seg.Angle1,
                endAngle: seg.Angle2
            });
        }
    }

    return {
        type: "outline",
        data: outlineData
    };
}



// -----------------------------
// ��ȡ������ݲ���װ JSON
// -----------------------------
function getBoardOutlineData() {
    if (!PCB_Board) PCB_Board = PCBServer.GetCurrentPCBBoard;
    if (!PCB_Board) {
        ShowMessage("û�� PCB �壡");
        return null; // ��ֵ
    }

    var outlineData = [];
    PCB_Board.BoardOutline.Invalidate;
    PCB_Board.BoardOutline.Rebuild;
    PCB_Board.BoardOutline.Validate;

    for (var i = 0; i < PCB_Board.BoardOutline.PointCount; i++) {
        var j = (i == PCB_Board.BoardOutline.PointCount - 1) ? 0 : i + 1;
        var seg = PCB_Board.BoardOutline.Segments(i);

        if (seg.Kind == ePolySegmentLine) {
            outlineData.push({
                kind: "line",
                x1: seg.vx,
                y1: seg.vy,
                x2: PCB_Board.BoardOutline.Segments(j).vx,
                y2: PCB_Board.BoardOutline.Segments(j).vy
            });
        } else { // ��
            outlineData.push({
                kind: "arc",
                cx: seg.cx,
                cy: seg.cy,
                radius: seg.Radius,
                startAngle: seg.Angle1,
                endAngle: seg.Angle2
            });
        }
    }

    // ͳһ��װ JSON ��
    return {
        type: "outline",
        data: outlineData
    };
}

// -----------------------------
// �������ݵ� Godot
// -----------------------------
function sendOutlineToGodot() {
    var payload = getBoardOutlineData();
    if (!payload) return; // û PCB��ֱ�ӷ���

    if (!tcpClient) connectToGodot("127.0.0.1", 6000);
    if (!tcpClient) return;

    try {
        var msg = JSON.stringify(payload) + "\n"; 
        tcpClient.SendData(msg);

        // �򵥵ȴ� Godot ȷ��
        WScript.Sleep(50);
        var resp = tcpClient.GetData();
        if (resp && resp.indexOf("OK") >= 0) {
            ShowMessage("������ݷ��ͳɹ���");
        } else {
            ShowMessage("δ�յ�ȷ�ϣ�");
        }
    } catch (e) {
        ShowMessage("�����쳣: " + e.message);
    }
}

/*======================================================================
   ����������ļ�����ť
=======================================================================*/
function bSendClick(Sender)
{
    bOKClick(Sender);
}

function bReceiveClick(Sender)
{
    ReceiveMessages();
}

function bCancelClick(Sender)
{
    GetScriptEngineInfo();
    Close;
}

/*======================================================================
   ����ڣ��ű�ִ��ʱ�Զ�����
=======================================================================*/
function Main()
{
    connectToGodot("127.0.0.1", 6000);
    sendOutlineToGodot();
}
