function GetScriptEngineInfo(){
   var s;
   s = ""; // Build string with necessary info.
   s += ScriptEngine() + " Version ";
   s += ScriptEngineMajorVersion() + ".";
   s += ScriptEngineMinorVersion() + ".";
   s += ScriptEngineBuildVersion();

   showmessage(s);
}

/*======================================================================
   ����������ļ�����ť
=======================================================================*/
function bSendClick(Sender)
{
    GetScriptEngineInfo();
    if(PCBServer == null)
        return;

    PCB_Board = PCBServer.GetCurrentPCBBoard;
    if(PCB_Board == null)
        return;

    Sender.Caption = "������...";

    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/send", false); // ͬ��
        http.setRequestHeader("Content-Type", "application/json");

        // ʾ�� Base64 �ļ������滻Ϊʵ���ļ�
        var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg==";
        http.send(JSON.stringify({ data: fileData }));

        if(http.status == 200 && http.responseText == "OK")
            Sender.Caption = "���ͳɹ�";
        else
            Sender.Caption = "����ʧ��";
    }
    catch(e)
    {
        Sender.Caption = "����ʧ��";
    }
}

/*======================================================================
   �����������Ϣ����ť
=======================================================================*/
function bReceiveClick(Sender)
{
    GetScriptEngineInfo();  
    if(PCBServer == null)
        return;

    PCB_Board = PCBServer.GetCurrentPCBBoard;
    if(PCB_Board == null)
        return;

    Sender.Caption = "������...";

    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", "http://127.0.0.1:8080/poll", false); // ͬ��
        http.send();
        var s;
        s = ""; // Build string with necessary info.
        s += ScriptEngine() + " Version ";
        s += ScriptEngineMajorVersion() + ".";
        s += ScriptEngineMinorVersion() + ".";
        s += ScriptEngineBuildVersion();

        showmessage(s);
        if(http.status == 200)
        {
            var resp = http.responseText;
            if(resp)
            {
                try
                {
                    var msgs = JSON.parse(resp);
                    if(msgs.length == 0)
                    {
                        ShowMessage("û������Ϣ");
                        Sender.Caption = "����Ϣ";
                    }
                    else
                    {
                        for(var i=0; i<msgs.length; i++)
                            ShowMessage("�յ� Godot ��Ϣ: " + msgs[i]);
                        Sender.Caption = "�������";
                    }
                }
                catch(e)
                {
                    ShowMessage("������Ϣʧ��");
                    Sender.Caption = "����ʧ��";
                }
            }
            else
            {
                ShowMessage("û���յ���Ϣ");
                Sender.Caption = "����Ϣ";
            }
        }
        else
        {
            ShowMessage("����ʧ��");
            Sender.Caption = "����ʧ��";
        }
    }
    catch(e)
    {
        ShowMessage("����ʧ��");
        Sender.Caption = "����ʧ��";
    }
}

function bCancelClick(Sender)
{
    GetScriptEngineInfo();
    Close;
}


// ���� POST ����
function httpPost(url, data, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", url, false); // ͬ��
        http.setRequestHeader("Content-Type", "application/json");
        http.send(JSON.stringify({ data: data }));
        if (http.status == 200 && http.responseText == "OK") callback(true);
        else callback(false);
    } catch(e){ callback(false); }
}

// ���� GET ����
function httpGet(url, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", url, false); // ͬ��
        http.send();
        if (http.status == 200) callback(http.responseText);
        else callback(null);
    } catch(e){ callback(null); }
}
