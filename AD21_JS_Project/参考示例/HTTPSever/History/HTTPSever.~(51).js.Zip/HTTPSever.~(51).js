

////////////////////////////////////////////////////////////////////
// -----------------------------------------------------------------
// ��־���
function Log(msg) {
    ShowMessage(msg);
}

// -----------------------------------------------------------------
// �����ļ�
function SendFile(fileData) {
    Log("������...");
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/send", false);
        http.setRequestHeader("Content-Type", "application/json");
        http.send(JSON.stringify({ data: fileData }));

        if(http.status == 200 && http.responseText == "OK")
            Log("���ͳɹ�");
        else
            Log("����ʧ��: " + http.status);
    }
    catch(e) {
        Log("�����쳣: " + e.message);
    }
}

// -----------------------------------------------------------------
// ������Ϣ
function ReceiveMessages() {
    Log("������...");
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", "http://127.0.0.1:8080/poll", false);
        http.send();
        if(http.status == 200) {
            var resp = JSON.parse(http.responseText); // ȷ�� json2.js �Ѽ���
            if(resp.length === 0)
                Log("û������Ϣ");
            else
                for(var i=0;i<resp.length;i++)
                    Log("�յ���Ϣ: " + resp[i]);
        } else {
            Log("����ʧ��: " + http.status);
        }
    } catch(e) {
        Log("�����쳣: " + e.message);
    }
}

// -----------------------------------------------------------------
function GetScriptEngineInfo(){
   var s;
   s = ""; // Build string with necessary info.
   s += ScriptEngine() + " Version ";
   s += ScriptEngineMajorVersion() + ".";
   s += ScriptEngineMinorVersion() + ".";
   s += ScriptEngineBuildVersion();

   showmessage(s);
}

/*======================================================================
   ����������ļ�����ť
=======================================================================*/
function bSendClick(Sender)
{
    SendFile("VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg==");
}

function bReceiveClick(Sender)
{
    ReceiveMessages();
}

function bCancelClick(Sender)
{
    GetScriptEngineInfo();
    Close;
}

/*======================================================================
   ����ڣ��ű�ִ��ʱ�Զ�����
=======================================================================*/
function Main()
{
    GetScriptEngineInfo();
    try
    {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", "http://127.0.0.1:8080/send", false);
        http.setRequestHeader("Content-Type", "application/json");

        var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg==";
        http.send(JSON.stringify({ data: fileData }));

        if(http.status == 200 && http.responseText == "OK")
            ShowMessage("���ͳɹ�");
        else
            ShowMessage("����ʧ��: " + http.status);
    }
    catch(e)
    {
        ShowMessage("�����쳣: " + e.message);
    }
}
