function httpPost(url, data, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", url, false); // ͬ����ʾ��
        http.setRequestHeader("Content-Type", "application/json");
        http.send(JSON.stringify({ data: data }));
        if (http.status == 200) callback(http.responseText);
        else callback(null);
    } catch(e) {
        callback(null);
    }
}

function httpGet(url, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", url, false);
        http.send();
        if (http.status == 200) callback(http.responseText);
        else callback(null);
    } catch(e) {
        callback(null);
    }
}

// ʾ�������� Base64 �ļ�
var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg=="; // Base64 ʾ��
httpPost("http://127.0.0.1:8080/send", fileData, function(resp){
    if(resp) ShowMessage("���ͳɹ�: " + resp);
});

// ��ѯ������Ϣ
function poll() {
    httpGet("http://127.0.0.1:8080/poll", function(resp){
        if(resp) {
            var msgs = JSON.parse(resp);
            for(var i=0;i<msgs.length;i++){
                ShowMessage("�յ� Godot ��Ϣ: " + msgs[i]);
            }
        }
        setTimeout(poll, 500); // ÿ500ms��ѯһ��
    });
}

poll();
