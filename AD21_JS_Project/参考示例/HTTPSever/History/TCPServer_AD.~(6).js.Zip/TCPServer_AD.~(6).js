// ���� POST ����
function httpPost(url, data, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("POST", url, false); // ͬ����ʽ
        http.setRequestHeader("Content-Type", "application/json");
        http.send(JSON.stringify({ data: data }));
        if (http.status == 200) callback(http.responseText);
        else callback(null);
    } catch(e) {
        callback(null);
    }
}

// ���� GET ����
function httpGet(url, callback) {
    try {
        var http = new ActiveXObject("MSXML2.XMLHTTP");
        http.open("GET", url, false); // ͬ����ʽ
        http.send();
        if (http.status == 200) callback(http.responseText);
        else callback(null);
    } catch(e) {
        callback(null);
    }
}

// ���� Base64 �ļ��� Godot TCPServer
var fileData = "VGhpcyBpcyBhIHNhbXBsZSBmaWxlLg=="; // ʾ�� Base64
httpPost("http://127.0.0.1:8080/send", fileData, function(resp){
    if(resp) ShowMessage("���ͳɹ�: " + resp);
    else ShowMessage("����ʧ��");
});

// ��ѯ������Ϣ
function poll() {
    httpGet("http://127.0.0.1:8080/poll", function(resp){
        if(resp) {
            try {
                var msgs = JSON.parse(resp);
                for(var i=0;i<msgs.length;i++){
                    ShowMessage("�յ� Godot ��Ϣ: " + msgs[i]);
                }
            } catch(e) {
                ShowMessage("������Ϣʧ��: " + resp);
            }
        }
        // ÿ 500ms ��ѯһ��
        setTimeout(poll, 500);
    });
}

poll();

